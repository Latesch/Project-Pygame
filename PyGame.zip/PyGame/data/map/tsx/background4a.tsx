<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.3" name="background4a" tilewidth="16" tileheight="16" tilecount="1800" columns="60">
 <image source="../tiles/background4a.png" width="960" height="480"/>
</tileset>
